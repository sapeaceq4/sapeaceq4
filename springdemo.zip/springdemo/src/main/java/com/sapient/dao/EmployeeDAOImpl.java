package com.sapient.dao;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.sapient.pojo.Employee;
import com.sapient.service.EmployeeRowMapper;



public class EmployeeDAOImpl implements EmployeeDAO {
	
	
	

	 private JdbcTemplate jdbctemplate ;
	
	 public void setDataSource(JdbcTemplate dataSource) {
			this.jdbctemplate = dataSource;
		} 
	
	@Transactional
	public void saveEmployee(Employee emp)
	{
		final String insert="insert into Employee" + "(id,name,age)values(?,?,?)";
		jdbctemplate.update(insert,new Object[]{emp.getId(),emp.getName(),emp.getAge()});
		updateCount();
		
	}
	
	public void updateCount()
	{
		String sql = "select count from Count where id = 1";
		int count=jdbctemplate.queryForInt(sql);
		++count;
		System.out.println(count);
		String sql1= "UPDATE Count SET count= " + count +" WHERE id=1";
		jdbctemplate.update(sql1);
	}
	
		public Employee findByEmpId(int empId) {
				String sql = "select * from Employee where id = " + empId;
				return (Employee) jdbctemplate.query(sql, new EmployeeRowMapper() ).get(0);
				
			} 

	
}
