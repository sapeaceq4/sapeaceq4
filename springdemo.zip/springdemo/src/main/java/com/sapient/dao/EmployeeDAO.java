package com.sapient.dao;

import java.util.List;

import com.sapient.pojo.Employee;

public interface EmployeeDAO {

	public void saveEmployee(Employee emp);

	public Employee findByEmpId(int i);
	
}
