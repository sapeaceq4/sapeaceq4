package com.sapient.service;



	
	import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.sapient.pojo.Employee;

	public class EmployeeRowMapper implements RowMapper
	{
		public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			Employee emp = new Employee(rs.getInt("id"), rs.getString("name"), rs.getInt("age"));
			return emp;
		} 
}
