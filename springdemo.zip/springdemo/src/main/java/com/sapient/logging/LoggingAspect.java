package com.sapient.logging;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class LoggingAspect {

	@Before("execution(* com.sapient.dao.EmployeeDAOImpl.saveEmployee(..))")
	public void logBefore(JoinPoint joinPoint) {

		System.out.println("logBefore() is running!");
		
		System.out.println("******");
	}

	@After("execution(* com.sapient.dao.EmployeeDAOImpl.saveEmployee(..))")
	public void logAfter(JoinPoint joinPoint) {

		System.out.println("logAfter() is running!");
		
		System.out.println("******");
	}
	
	@Around("execution(* com.sapient.dao.EmployeeDAOImpl.saveEmployee(..))")
	public void logAround(ProceedingJoinPoint joinPoint) throws Throwable {

		System.out.println("logAround() is running!");
		
		System.out.println("******");
		joinPoint.proceed();
	}
}
