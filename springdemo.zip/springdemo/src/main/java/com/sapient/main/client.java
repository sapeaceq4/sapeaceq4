package com.sapient.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sapient.dao.EmployeeDAO;
import com.sapient.pojo.Employee;

public class client {

	
	public static void main( String[] args )
    {
    	ApplicationContext context = new ClassPathXmlApplicationContext("configure.xml");
    	 
        EmployeeDAO customerDAO = (EmployeeDAO) context.getBean("empDAO");
        Employee empToCreate = new Employee(7, "Kirti",56);
        customerDAO.saveEmployee(empToCreate);
    	
        Employee emp = customerDAO.findByEmpId(1);
        System.out.println(emp);
        
    } 
}
