package com.sapient.pojo;

import java.io.Serializable;

import org.aspectj.lang.annotation.Aspect;

@Aspect
public class Employee implements Serializable {
	
	String name;
	int age;
	int id;
	
	public Employee(int int1, String string, int int2) {
		this.name=string;
		this.id=int1;
		this.age=int2;
		
	
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", age=" + age + ", id=" + id + "]";
	}
	
}
