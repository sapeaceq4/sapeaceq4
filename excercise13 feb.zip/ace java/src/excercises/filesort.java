package excercises;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Date;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;


public class filesort {

	
	 public static void main(String[] args) throws Exception {
			
			long t1 = new Date().getTime();
			Set<String> set = new TreeSet<String>();
			BufferedReader br = new BufferedReader(new FileReader(new File("C:\\project\\sampleinput.txt")));
			String s = br.readLine();		
			while( s != null ) {
				set.add(s);
				s = br.readLine();
			}
			br.close();
			
			FileWriter fw = new FileWriter(new File("C:\\project\\output1.txt"));
			for (String x: set) {
				fw.write(x);
				
				fw.append('\n');
			}
			fw.close();
			long t2 = new Date().getTime();
			System.out.println("Time taken = " +(t2-t1)/1000 + " sec");
			
		}
	
	
	
}
